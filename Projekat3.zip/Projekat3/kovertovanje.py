import pandas as pd
import os

# Proverite trenutni radni direktorijum
print("Trenutni radni direktorijum:", os.getcwd())

# Relativna putanja do CSV fajla
csv_file = 'asthma_disease_data.csv'

# Proverite da li fajl postoji
if not os.path.exists(csv_file):
    print(f"Fajl {csv_file} ne postoji u tekućem direktorijumu.")
else:
    # Učitajte CSV fajl koristeći pandas
    df = pd.read_csv(csv_file)

    # Definišite meta podatke za ARFF
    relation_name = 'asthma_disease_data'

    # Mapiranje tipova podataka
    def map_dtype(dtype):
        if dtype == 'object':
            return 'STRING'
        elif dtype == 'int64' or dtype == 'float64':
            return 'NUMERIC'
        else:
            return 'STRING'

    attributes = [(col, map_dtype(dtype)) for col, dtype in df.dtypes.items()]

    # Pišite ARFF fajl
    arff_file = 'asthma_disease_data.arff'
    with open(arff_file, 'w') as f:
        f.write(f"@RELATION {relation_name}\n\n")
        for attr_name, attr_type in attributes:
            f.write(f"@ATTRIBUTE {attr_name} {attr_type}\n")
        f.write("\n@DATA\n")
        for row in df.itertuples(index=False, name=None):
            f.write(','.join(map(str, row)) + '\n')

    print(f"ARFF fajl je uspešno kreiran: {arff_file}")
