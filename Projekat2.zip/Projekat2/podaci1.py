import os
from google.cloud import bigquery
import pandas as pd

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'projekat2-423813-ac155e5927c6.json'

client = bigquery.Client()

project_id = 'projekat2-423813'
dataset_id = 'projekat2-423813.podaci'
table_id = "projekat2-423813.podaci.podaci1"

df = pd.read_csv('podaci1.csv')

job_config = bigquery.LoadJobConfig()
job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE

client.load_table_from_dataframe(df, table_id, job_config=job_config)

print(f"Podaci su učitani u {project_id}.{dataset_id}.{table_id}")
