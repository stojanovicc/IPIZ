#izdvajamo filmove koji imaju ocenu iznad 8
#prikazuje se id, naziv, zanr, reziser, glavni_glumac, zemlja

from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col, current_timestamp

spark = SparkSession.builder.master("local[2]").appName("FilmDataStreaming").getOrCreate()

socketDF = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

parsed_df = socketDF.selectExpr("split(value,',') AS data")

parsedDF = parsed_df.selectExpr(
    "CASE WHEN data[0] = 'null' THEN NULL ELSE CAST(data[0] AS INT) END as id",
    "CASE WHEN data[1] = 'null' THEN NULL ELSE data[1] END as naslov",
    "CASE WHEN data[2] = 'null' THEN NULL ELSE data[2] END as zanr",
    "CAST(data[3] AS INT) as trajanje",
    "CASE WHEN data[4] = 'null' THEN NULL ELSE data[4] END as reziser",
    "CASE WHEN data[5] = 'null' THEN NULL ELSE data[5] END as glavni_glumac",
    "CASE WHEN data[6] = 'null' THEN NULL ELSE data[6] END as zemlja",
    "CASE WHEN data[7] = 'null' THEN NULL ELSE CAST(data[7] AS FLOAT) END as ocena",
    "data[8] as bioskop",
    "data[9] as grad",
    "CAST(data[10] AS INT) as kapacitet",
    "CAST(data[11] AS INT) as cena_karte",
    "CAST(data[12] AS INT) as id_bioskopa"
)

# filtriranje filmova s ocenom vecom od 8 i prikazivanje odabranih kolona
filteredDF = parsedDF.filter(col("ocena") > 8).select(
    "id",
    "naslov", 
    "zanr", 
    "reziser",
    "glavni_glumac",
    "zemlja"
)

coalescedDF = filteredDF.coalesce(1)

query = coalescedDF.writeStream \
        .outputMode("append") \
        .format("console") \
        .start()

query = coalescedDF.writeStream \
    .outputMode("append") \
    .format("csv") \
    .option("path", ".output1") \
    .option("checkpointLocation", ".checkpoint1") \
    .option("header", "true") \
    .start()

query.awaitTermination()
