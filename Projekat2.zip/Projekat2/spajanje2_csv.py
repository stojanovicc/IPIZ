import os
import csv

folder_path = os.path.join(os.getcwd(), '.output2')

output_file = 'podaci2.csv'

all_data = []

for filename in os.listdir(folder_path):
    if filename.endswith('.csv'):
        file_path = os.path.join(folder_path, filename)
        with open(file_path, 'r', newline='') as csvfile:
            reader = csv.reader(csvfile)
            data = list(reader)
            all_data.extend(data[1:])  

with open(output_file, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(data[0])
    writer.writerows(all_data)

print("Podaci su uspešno spojeni u fajl:", output_file)
