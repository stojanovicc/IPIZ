#veza izmedju filmova i bioskopa
#prikazuje se id filma, bioskop, grad, trajanje, ocena, cena_karte

from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col

spark = SparkSession.builder.master("local[2]").appName("FilmDataStreaming").getOrCreate()

socketDF = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

parsed_df = socketDF.selectExpr("split(value,',') AS data")

parsedDF = parsed_df.selectExpr(
    "CASE WHEN data[0] = 'null' THEN NULL ELSE CAST(data[0] as INT) END as id",
    "data[1] as naslov",
    "data[2] as zanr",
    "CASE WHEN data[3] = 'null' THEN NULL ELSE CAST(data[3] AS INT) END as trajanje",
    "data[4] as reziser",
    "data[5] as glavni_glumac",
    "data[6] as zemlja",
    "CASE WHEN data[7] = 'null' THEN NULL ELSE CAST(data[7] AS FLOAT) END as ocena",
    "CASE WHEN data[8] = 'null' THEN NULL ELSE data[8] END as bioskop",
    "CASE WHEN data[9] = 'null' THEN NULL ELSE data[9] END as grad",
    "data[10] AS kapacitet",
    "CASE WHEN data[11] = 'null' THEN NULL ELSE CAST(data[11] AS INT) END as cena_karte",
    "CASE WHEN data[12] = 'null' THEN NULL ELSE CAST(data[12] AS INT) END as id_bioskopa"
)

filteredDF = parsedDF.filter(col("ocena") > 8).select(
    "id",
    "id_bioskopa", 
    "trajanje",
    "ocena",
    "cena_karte"
)

coalescedDF = filteredDF.coalesce(1)

query = coalescedDF.writeStream \
        .outputMode("append") \
        .format("console") \
        .start()

query = coalescedDF.writeStream \
    .outputMode("append") \
    .format("csv") \
    .option("path", ".output3") \
    .option("checkpointLocation", ".checkpoint3") \
    .option("header", "true") \
    .start()

query.awaitTermination()
