import socket
import random
import time
import threading

def handle_client(client_socket, data_file_path):

    with open(data_file_path, mode="r", encoding='utf-8-sig') as data_file:
        lines = data_file.readlines()
        try:
            i = 0
            while i< len(lines):
                print("sending")
                client_socket.send(lines[i].encode())
                client_socket.send(lines[i+1].encode())
                client_socket.send(lines[i+2].encode())
                client_socket.send(lines[i+3].encode())
                i = i+4
                time.sleep(5)
        except:
            print("error")
        finally:
            print("closing")
            client_socket.close()

def start_server(host, port, data_file_path):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen()
    print(f"Server listening on {host}:{port}")

    while True:
        client_socket, address = server_socket.accept()
        print(f"Client connected from {address[0]}:{address[1]}")
        client_thread = threading.Thread(target=handle_client, args=(client_socket, data_file_path))
        client_thread.start()


if __name__ == "__main__":
    host = 'localhost' 
    port = 9999  
    start_server(host, port, "podaci.txt")