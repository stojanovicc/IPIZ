#izdvajanje bioskopa bez duplikata
#prikaz id_bioskopa, bioskop, grad, kapacitet

from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col, count, concat, lit
from pyspark.sql.window import Window
from pyspark.sql.functions import expr
from pyspark.sql.functions import *

spark = SparkSession.builder.master("local[2]").appName("FilmDataStreaming").getOrCreate()

socketDF = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

parsed_df = socketDF.selectExpr("split(value,',') AS data")

parsedDF = parsed_df.selectExpr(
    "data[0] as id",
    "data[1] as naslov",
    "data[2] as zanr",
    "CAST(data[3] AS INT) as trajanje",
    "data[4] as reziser",
    "data[5] as glavni_glumac",
    "data[6] as zemlja",
    "CAST(data[7] AS FLOAT) as ocena",
    "CASE WHEN data[8] = 'null' THEN NULL ELSE data[8] END as bioskop",
    "CASE WHEN data[9] = 'null' THEN NULL ELSE data[9] END as grad",
    "CASE WHEN data[10] = 'null' THEN NULL ELSE CAST(data[10] AS INT) END as kapacitet",
    "CASE WHEN data[11] = 'null' THEN NULL ELSE CAST(data[11] AS INT) END as cena_karte",
    "CASE WHEN data[12] = 'null' THEN NULL ELSE CAST(data[12] AS INT) END as id_bioskopa"
)

cinemaDF = parsedDF.select(
    "id_bioskopa",
    "bioskop", 
    "grad", 
    "kapacitet"
)

cinemaDF = cinemaDF.dropDuplicates(["id_bioskopa"])

query1 = cinemaDF.writeStream \
    .outputMode("append") \
    .format("console") \
    .start()

query2 = cinemaDF.writeStream \
    .outputMode("append") \
    .format("csv") \
    .option("path", ".output2") \
    .option("checkpointLocation", ".checkpoint2") \
    .option("header", "true") \
    .start()

query1.awaitTermination()
query2.awaitTermination()
